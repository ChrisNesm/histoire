<a href="detailsetudiant.php?ide=<?php echo $row['id'];?>">
<p><?php echo"". $row["nom"]." ".$row["prenoms"]." ".$row['email']." ".$row['motdepasse'];
?></p>   
</a>